This directory contains three one-pagers for the projects:

1. Void Tech - in-orbit satellite servicing with the hive of nanosat drones
2. Echoes - AI-enhanced journaling app
3. Voidwalker - performance analysis for Apex Legends videogame players

Project Voidwalker has an open-source code base with the GitHub link provided within the one-pager, the other two projects are covered by non-disclosure agreements.

I would be happy to answer any questions at theo.issena@gmail.com


P.S. Made with love <3